1. Install the desired text-to-speech language per these instructions: http://superuser.com/questions/590779/how-to-install-more-voices-to-windows-speech
2. Install that language's keyboard in your Windows, if needed
3. Swap to that language (Alt-Shift)
4. Run BabySmash.exe
5. If you want to support shape and color names for that language, create a new file in Resources/Strings (ensure the correct culture name)